#include <stdio.h>
#include <stdlib.h>

void fun1(int *ptr1)
{
int i;
char div[]="**********************************";
printf("Funcion 1:\n");
 for(i=0;i<5;i++)
 {
 printf("%d\t",ptr1[i]); 				 
 } 	 
printf("\n%s\n",div); 
}

void fun2(int *ptr1, int *ptr2, int *ptr3)
{
int i,res;
printf("Funcion 2:\nCadena original:\n");
 for(i=0;i<5;i++)
 {
 printf("%d\t",ptr1[i]);				 
 } 	
printf("\nArreglo No. 2:\n");
 for(i=0;i<5;i++)
 {
 printf("%d\t",ptr2[i]);				 
 } 
printf("\nSuma de las dos cadenas :\n");
 for(i=0;i<5;i++)
 {
 ptr3[i]=ptr1[i]+ptr2[i];			 
 } 	 
}
 
void fun3(int *ptr1, int *ptr4)
{
int i;
char div[]="**********************************";
printf("Funcion 3:\nCadena original:\n"); 
 for(i=0;i<5;i++)
 {
 printf("%d\t",ptr1[i]);
 ptr4[4-i]=ptr1[i];			 
 } 	
printf("\nCadena invertida:\n");
for(i=0;i<5;i++)
 {
 printf("%d\t",ptr1[4-i]); 				 
 }	 
printf("\n%s\n",div);
}

void fun4(int *ptr1, char *ptr5)
{
int i;
printf("Funcion 4:\nCadena original:\n");
 for(i=0;i<5;i++)
 {
 printf("%d\t",ptr1[i]);				 
 } 
printf("\nCadena par o impar:\n");
 for(i=0;i<5;i++)
 {
  if(ptr1[i]%2==0)
  {
  ptr5[i]='P';			  
  } 			
  else
  {
  ptr5[i]='I'; 	  
  }	 
 }	
}

int main(int argc, char *argv[])
{
int arreglo1[]={9,8,14,1,0},arreglo2[]={7,6,8,2,6},arreglo3[5],arreglo4[5],i;
char arreglo5[5];
int *ptr1,*ptr2,*ptr3,*ptr4;
char *ptr5;
char div[]="**********************************";
ptr1=&arreglo1;
ptr2=&arreglo2;
ptr3=&arreglo3;
ptr4=&arreglo4;
ptr5=&arreglo5;
fun1(ptr1);
fun2(ptr1,ptr2,ptr3);
system("color F5");
 for(i=0;i<5;i++)
 {
 printf("%d\t",ptr3[i]);			 
 } 
printf("\n%s\n",div);
fun3(ptr1,ptr4);
fun4(ptr1,ptr5);
 for(i=0;i<5;i++)
 {
 printf("%c\t",ptr5[i]);
 }
printf("\n%s\n",div);
system("PAUSE");	
return 0;
}
