#include <iostream>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
int cant_mesas(int a);
int ocupar_mesas();
int menu();
int pago(int x[],int y);
void portada() {
	//MARANTA
	char a=178,b=32,c=32;
	char columna[100][100]={
	{c,c,c,c,c,a,a,a,a,b,a,b,a,a,a,a,b,a,b,b,b,a,c,a,b,b,b,a,c,a,a,a,a,c,a,b,b,b,a,c,a,c,a,a,a,b,c,a,a,a,a,c,a,a,a,a,c},
	{c,c,c,c,c,a,b,b,a,b,a,b,a,b,b,b,b,a,a,b,b,a,c,a,b,b,b,a,c,a,b,b,b,c,a,a,b,b,a,c,a,c,a,b,a,a,c,a,b,b,a,c,a,b,b,b,c}
   ,{c,c,c,c,c,a,a,a,a,b,a,b,a,a,a,a,b,a,b,a,b,a,c,b,a,b,a,b,c,a,a,a,a,c,a,b,a,b,a,c,a,c,a,b,b,a,c,a,b,b,a,c,a,a,a,a,c},
	{c,c,c,c,c,a,b,b,a,b,a,b,a,b,b,b,b,a,b,b,a,a,c,b,a,b,a,b,c,a,b,b,b,c,a,b,b,a,a,c,a,c,a,b,a,a,c,a,b,b,a,c,b,b,b,a,c},
	{c,c,c,c,c,a,a,a,a,b,a,b,a,a,a,a,b,a,b,b,b,a,c,b,b,a,b,b,c,a,a,a,a,c,a,b,b,b,a,c,a,c,a,a,a,b,c,a,a,a,a,c,a,a,a,a,c}
	,{},
	{c,c,c,c,c,c,c,c,c,b,b,a,b,b,c,c,c,c,c,c,c,c,a,b,b,b,a,c,b,b,a,b,b,c,a,b,b,b,a,c,b,b,a,b,b,c,a,b,b,b,a,c,a,a,a,a,c,a,c,a,b,b,b,a},
	{c,c,c,c,c,c,c,c,c,b,a,b,a,b,c,c,c,c,c,c,c,c,a,b,b,b,a,c,b,a,b,a,b,c,a,a,b,b,a,c,b,a,b,a,b,c,a,b,b,b,a,c,a,c,c,c,c,a,c,a,a,b,b,a},
	{c,c,c,c,c,c,c,c,c,b,a,b,a,b,c,c,c,c,c,c,c,c,b,a,b,a,b,c,b,a,b,a,b,c,a,b,a,b,a,c,b,a,b,a,b,c,a,a,a,a,a,c,a,a,a,a,c,a,c,a,b,a,b,a},
	{c,c,c,c,c,c,c,c,c,a,a,a,a,a,c,c,c,c,c,c,c,c,b,a,b,a,b,c,a,a,a,a,a,c,a,b,b,a,a,c,a,a,a,a,a,c,a,b,b,b,a,c,a,c,c,c,c,a,c,a,b,b,a,a},
	{c,c,c,c,c,c,c,c,c,a,b,b,b,a,c,c,c,c,c,c,c,c,b,b,a,b,b,c,a,b,b,b,a,c,a,b,b,b,a,c,a,b,b,b,a,c,a,b,b,b,a,c,a,a,a,a,c,a,c,a,b,b,b,a}}; //05espacio
	int i,j;
	system("color F4");
	for(i=0;i<12;i++){
		
		for(j=0;j<70;j++){
			
		printf("%c",columna[i][j]);
	    
		}
	printf("\n");
	}
	printf("                             El lugar donde comes por ultima vez");
	printf("\n");
system("pause");

}
//char menu_r(char menur[]);
int agr_cuenta(int mesa[] );
int seleccion(int tot[],int y);

int main(int argc, char** argv) {
	int a,plat,nm;
	portada();
	system("cls");
	a=cant_mesas(a);
	int t_mesas[a]={};
	int tot[a]={},*toto;
	int total=0;
	toto=(int*)malloc(sizeof(int));

	system("cls");
	int opc,i;
	opc=1;
	while(opc!=4){
	opc=menu();
	system("pause");
	
	switch (opc){
		case 1:
			nm=ocupar_mesas();
			t_mesas[nm]=1;
		

			printf("La mesa %d esta ocupada  \n",nm);
			system("pause");
		break;
		case 2:
			printf("seleccion\n");
	  		tot[nm]=seleccion(tot,nm);
	  		
	  		system("pause");
		break;
		case 3:
			int ul=nm;
//			printf("Coloque el numero de mesa a calcular la cuenta:");
//			for(int i=0;i<nm;i++){
//				printf("%d ",tot[i]);
//			}
//	scanf("%d",&ul);
//			system("pause");
			pago(tot,ul);
					
		
		break;
		
	}
}

			
	
	return 0;
}

int cant_mesas(int a){
	printf("Ingrese el numero total de mesas:\t");
	scanf("%d",&a);
	return a;
}


int ocupar_mesas(){
	int nm;
	printf("Ingrese el numero de la mesa que se acaba de ocupar");
	scanf("%d",&nm);
	return nm;
}

int menu(){
	int opc1;
	system("cls");
	printf("1.-\tIngresar mesa\n2.-\tAgregar a la cuenta\n3.-\tRegistrar pago\n4.-\tSalir del programa\n");
	printf("Ingrese la accion a realizar: ");
	scanf("%d",&opc1);
	return opc1;
}

	void subH(){
        printf("Hamburguesa sencilla\t$30\t(s)\n");
        printf("Hamburguesa mediana\t$42\t(M)\n");
        printf("Hamburguesa suprema\t$50\t(S)\n\n");
        }
void subP(){
        printf("Pizza de Peperoni\t$150\t(P)\n");
        printf("Pizza Hawaiana\t\t$130\t(H)\n");
        printf("Pizza de 3 quesos\t$180\t(Q)\n\n");
     }

void subT(){
        printf("Torta de Milanesa\t$40\t(m)\n");
        printf("Torta de Pierna\t\t$48\t(p)\n");
        printf("Torta de Chorizo\t$45\t(c)\n\n");    
     }
void subO(){
        printf("Hot Dogs\t\t$25\t(D)\n");  
        printf("Papas a la francesa\t$23\t(F)\n");
        printf("Nugets\t\t\t$18\t(G)\n\n"); 
     }
void subB(){
        printf("Agua de limon\t\t$15\t(L)\n");
        printf("Agua de orchata\t\t$17\t(O)\n");
        printf("Jugo de naranja\t\t$15\t(N)\n");
        printf("Jugo de toronja\t\t$17\t(T)\n");
        printf("Cafe\t\t\t$18\t(C)\n");
        printf("Coca-Cola\t\t$20\t(R)\n\n");      
     }
void menu2(){
    
        printf("MENU\n\n");
        printf("El menu a elegir es el siguiente:\n\n");
        
        printf("Hamburguesas\t\t\t\t(1)\n");
        subH();
        
        printf("Pizzas\t\t\t\t\t(2)\n");
        subP();
        
        printf("Tortas\t\t\t\t\t(3)\n");
        subT();
        
        printf("Otros\t\t\t\t\t(4)\n");
        subO();     
        
        printf("Bebidas\t\t\t\t\t(5)\n");
        subB();    
         
     }

int seleccion(int tot[],int y){
     int categ, x, uni,total;
     int totH1=0,totH2=0,totH3=0,totP1=0,totP2=0,totP3=0,totT1=0,totT2=0,totT3=0,totB1=0,totB2=0,totB3=0,totB4=0,totB5=0,totO1=0,totO2=0,totO3=0;
     char ingresar,produc;

	 x=1;
     while(x>0){
     menu2();
     printf("A que categoria desea ingresar?   ");
     scanf("%d",&categ);
      switch(categ){
                     case 1: printf("Usted Ingreso Hamburgueas\n\n");                              
                             printf("Que producto desea ordear?\n");
                             subH();
                             scanf(" %c",&produc);
                             switch(produc){
                                            case 's': printf("Usted ordeno Hamburguesa Sencilla\n\n");
                                            		  printf("Cuantas unidades desea ordenar   ");
                                            		  scanf("%d",&uni);
                                            		  totH1=uni*30;
                                            break;
                                            case 'M': printf("Usted ordeno Hamburguesa Mediana\n\n");
                                           			  printf("Cuantas unidades desea ordenar   ");
                                            		  scanf("%d",&uni);
                                            		  totH2=uni*40;
                                            break;
                                            case 'S': printf("Usted ordeno Hamburguesa Suprema\n\n");
													  printf("Cuantas unidades desea ordenar   ");
                                            		  scanf("%d",&uni);
                                            		  totH3=uni*50;                                    
                                            break;
                                            default: printf("Error vuelva a ingresar su producto\n");
                                            } 
                             break; 
                     case 2: printf("Usted Ingreso Pizzas\n\n");                              
                             printf("Que producto desea ordear?\n");
                             subP();
                             scanf(" %c",&produc);
                             switch(produc){
                                            case 'P': printf("Usted ordeno Pizza de Peperoni\n\n");
                                            printf("Cuantas unidades desea ordenar   ");
                                            scanf("%d",&uni);
                                            totP1=uni*150;
                                            break;
                                            case 'H': printf("Usted ordeno Pizza Hawaiana\n\n");
                                            printf("Cuantas unidades desea ordenar   ");
                                            scanf("%d",&uni);
                                            totP2=uni*130;
                                            break;
                                            case 'Q': printf("Usted ordeno Pizza de 3 Quesos\n\n");
                                            printf("Cuantas unidades desea ordenar   ");
                                            scanf("%d",&uni);
                                            totP3=uni*180;
                                            break;
                                            default: printf("Error vuelva a ingresar su producto\n");
                                            } 
                             break; 
                     case 3: printf("Usted Ingreso Tortas\n\n");                              
                             printf("Que producto desea ordear?\n");
                             subT();
                             scanf(" %c",&produc);
                             switch(produc){
                                            case 'm': printf("Usted ordeno Torta de Milanesa\n\n");
                                            		  printf("Cuantas unidades desea ordenar   ");
                                            		  scanf("%d",&uni);
                                            		  totT1=uni*42;
                                            break;
                                            case 'p': printf("Usted ordeno Torta de Pierna\n\n");
                                            		  printf("Cuantas unidades desea ordenar   ");
                                            		  scanf("%d",&uni);
                                            		  totT2=uni*48;
                                            break;
                                            case 'c': printf("Usted ordeno Torta de Chorizo\n\n");
                                            		  printf("Cuantas unidades desea ordenar   ");
                                            		  scanf("%d",&uni);
                                            		  totT3=uni*45;
                                            break;
                                            default: printf("Error vuelva a ingresar su producto\n");
                                            } 
                             break;      
                     case 4: printf("Usted Ingreso Otros\n\n");                              
                             printf("Que producto desea ordear?\n");
                             subO();
                             scanf(" %c",&produc);
                             switch(produc){
                                            case 'D': printf("Usted ordeno Hot Dogs\n\n");
                                            		  printf("Cuantas unidades desea ordenar   ");
                                            		  scanf("%d",&uni);
                                            		  totO1=uni*25;
                                            break;
                                            case 'F': printf("Usted ordeno Papas a la Francesa\n\n");
                                            		  printf("Cuantas unidades desea ordenar   ");
                                            		  scanf("%d",&uni);
                                            		  totO2=uni*23;
                                            break;
                                            case 'G': printf("Usted ordeno Nugets\n\n");
                                            		  printf("Cuantas unidades desea ordenar   ");
                                            		  scanf("%d",&uni);
                                           		 	  totO3=uni*18;
                                            break;
                                            default: printf("Error vuelva a ingresar su producto\n");
                                            } 
                             break;                                                                         
                     case 5: printf("Usted Ingreso Bebidas\n\n");                              
                             printf("Que producto desea ordear?\n");
                             subB();
                             scanf(" %c",&produc);
                             switch(produc){
                                            case 'L': printf("Usted ordeno Agua de Limon\n\n");
                                            		  printf("Cuantas unidades desea ordenar   ");
                                           			  scanf("%d",&uni);
                                            		  totB1=uni*15;
                                            break;
                                            case 'O': printf("Usted ordeno Agua de Orchata\n\n");
                                            		  printf("Cuantas unidades desea ordenar   ");
                                            		  scanf("%d",&uni);
                                            		  totB2=uni*17;
                                            break;
                                            case 'N': printf("Usted ordeno Jugo de Naranja\n\n");
                                            		  printf("Cuantas unidades desea ordenar   ");
                                            		  scanf("%d",&uni);
                                            	 	  totB3=uni*15;
                                            break;
                                            case 'T': printf("Usted ordeno Jugo de Toronja\n\n");
                                            		  printf("Cuantas unidades desea ordenar   ");
                                            		  scanf("%d",&uni);
                                           		      totB4=uni*17;
                                            break;
                                            case 'C': printf("Usted ordeno Cafe\n\n");
                                            		  printf("Cuantas unidades desea ordenar   ");
                                            		  scanf("%d",&uni);
                                            		  totB5=uni*18;
                                            break;
                                            case 'R': printf("Usted ordeno Coca-Cola\n\n");
                                            		  printf("Cuantas unidades desea ordenar   ");
                                            		  scanf("%d",&uni);
                                            		  totB5=uni*20;
                                            break;
                                            default: printf("Error vuelva a ingresar su producto\n");
                                            } 
                             break;  
                     default:printf("Error vuela a ingresar la categoria\n");
                             }
                                      
 
                     
      printf("Desea ingresar o reingresar otra categoria?\n\nSi es un SI ingrese s, si es un No ingrese cualquier otra letra\n");
      scanf(" %c",&ingresar);
      if(ingresar=='S'||ingresar=='s'){x=1;}else{
                                       x=0;
                                       tot[0]=totH1+totH2+totH3;
                                       tot[1]=totP1+totP2+totP3;
                                       tot[2]=totT1+totT2+totT3;
                                       tot[3]=totO1+totO2+totO3;
                                       tot[4]=totB1+totB2+totB3+totB4+totB5;
                                       tot[5]=tot[0]+tot[1]+tot[2]+tot[3]+tot[4];
                                       }}
                                       return tot[5];
}

int pago(int x[],int y){
	int a,efec;
	printf("(0) Tarjeta de credito\n(1)Efectivo\n");
	printf("La forma de pago es:");
	scanf("%d",&efec);
	switch (efec){
	case 0: 
	    
		printf("Pago exitoso\n");
		printf("El total es %d\n",x[y]);
	    printf("Imprimiendo su comprobante\n");
	    printf("Que tenga un excelente dia\n");
	    system("pause");
	break;
	case 1: 
	  printf("El total es %d\n",x[y]);
	  printf("Gracias por su pago\n");
	  printf("Que tenga un excelente dia\n");
	  system("pause");
	break;
}
	
}
